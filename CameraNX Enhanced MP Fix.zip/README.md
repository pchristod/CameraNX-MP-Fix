# Magisk CameraNX Enhanced Motion Pictures Fix

Additional Files to fix Motion Pictures for the Enhanced Version of CameraNX on Android 8.x

This Module should work for the N5X and N6P

All credit goes to Charles_l, I just put this together into a Magisk Module

XDA-Topic for more (https://forum.xda-developers.com/nexus-6p/themes-apps/mod-camera-nx-v4-google-camera-zsl-hdr-t3494435)